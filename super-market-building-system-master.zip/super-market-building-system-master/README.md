# super-market-building-system
A basic android application of shopping cart(using sqlite in android studio)
This software project is a traditional supermarket godown system with some added functionality. This system is built for fast data processing and bill generation and godown for supermarket customers and manager respectively. The Management system consists of a fire
base database and designed using Android Studio. The database is a vast collection of product name, price and other product specific data. A product when billed is searched from the database and its price is added to the bill based upon the product quantity.
The supermarket billing system is built to help supermarkets calculate and display bills and serve the customer in a faster and efficient manner. It also helps manager to manage the quantity of products. This software project consists of an effective and easy GUI to help the
employees in easy bill calculation and providing an efficient customer service.
